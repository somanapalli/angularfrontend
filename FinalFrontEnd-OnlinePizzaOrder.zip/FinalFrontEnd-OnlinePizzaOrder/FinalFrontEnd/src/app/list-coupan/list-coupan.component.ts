import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Coupan, CoupanserviceService } from '../coupanservice.service';

@Component({
  selector: 'app-list-coupan',
  templateUrl: './list-coupan.component.html',
  styleUrls: ['./list-coupan.component.css']
})
export class ListCoupanComponent implements OnInit {
  coupan: Coupan[] = [];

  constructor(private myservice: CoupanserviceService,private router:Router) { }

  ngOnInit(): any {
    this.myservice.viewCoupans().subscribe(
      response => this.handleSuccessfulResponse(response),
    );
  }
  handleSuccessfulResponse(response:any){
    this.coupan=response;
  }
  // addCoupan(addcou:Coupan):any{
  //   this.myservice.addCoupan(addcou);
  //   this.router.navigate(['/add-coupan']);
  // }

  update(updatecou:Coupan){
    this.myservice.update(updatecou);
    this.router.navigate(['/update-coupan']);
  }
  deleteCoupan(deletecou:Coupan):any{
    var selection = confirm("Are you sure? Data will be deleted permanently!");
    if (selection) {
      console.log("Deleted");
    this.coupan.splice(this.coupan.indexOf(deletecou),1);
    this.myservice.deleteCoupan(deletecou.coupanId).subscribe(data=>{
      alert(data);
    });
    this.router.navigate(['/list-coupans']);
  }

  }
  column:string="coupanId";
  order:string="ascending";
  sort(column:string,order:string){
    this.column=column;
  
    if(this.order=="ascending")
      this.order="descending";
    else 
      this.order="ascending";
  }
  }
  



