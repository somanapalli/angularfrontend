import { Component, OnInit } from '@angular/core';
import { MyserviceService, Customer } from '../myservice.service';
import { Router } from '@angular/router';


@Component({
  selector: 'app-list-customer',
  templateUrl: './list-customer.component.html',
  styleUrls: ['./list-customer.component.css']
})
export class ListCustomerComponent implements OnInit {
  message: string;
  customers: Customer[];
  constructor(private myservice: MyserviceService, private router: Router) {
  }

  ngOnInit(): any {
    this.myservice.getCustomer().subscribe(
      response => this.handleSuccessfulResponse(response),
    );
  }

  handleSuccessfulResponse(response) {
    console.log(response);
    this.customers = response;
  }
  update(updateCustomer: Customer) {
    this.myservice.update(updateCustomer);
    this.router.navigate(['/updatecus']);
  }
  delete(deleteCustomer: Customer): any {
    var selection = confirm("Are you sure to delete!!")
    if (selection) {
      this.customers.splice(this.customers.indexOf(deleteCustomer), 1);
      this.myservice.delete(deleteCustomer.customerId).subscribe(data => {
      

      });
    }
    this.router.navigate(['/listcus']);
  }
  column:string="Id";
  order:string="ascending";
  sort(column:string,order:string){
    this.column=column;
   if(this.order=="ascending")
   this.order="descending";
   else this.order="ascending";
  }
}
