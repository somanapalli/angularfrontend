import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Customer, MyserviceService } from '../myservice.service';

@Component({
  selector: 'app-update-profile',
  templateUrl: './update-profile.component.html',
  styleUrls: ['./update-profile.component.css']
})
export class UpdateProfileComponent implements OnInit {
  obj1: any;
  Customer: Customer[];
  message: string;
  constructor(private myservice: MyserviceService, private router: Router) {
    this.obj1 = this.myservice.updateMethod();
    console.log(this.obj1);
  }
  
  onUpdate(ucustomer: Customer): any {
    if(confirm("Confirm your details")){
    return this.myservice.onUpdate(ucustomer).subscribe(data => {
      this.router.navigate(['/listcus'])
    });
  }
  }
  onUpdateProfile(ucustomer: Customer): any {
    if(confirm("Confirm your details")){
    return this.myservice.onUpdate(ucustomer).subscribe(data => {
      this.router.navigate(['/profile'])
    });
  }
  }
  ngOnInit(): void {
  }

}
