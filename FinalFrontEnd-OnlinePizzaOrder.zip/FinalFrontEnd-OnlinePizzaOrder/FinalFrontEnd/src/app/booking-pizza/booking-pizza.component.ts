import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Coupan, CoupanserviceService } from '../coupanservice.service';
import { PizzaserviceService } from '../pizzaservice.service';

@Component({
  selector: 'app-booking-pizza',
  templateUrl: './booking-pizza.component.html',
  styleUrls: ['./booking-pizza.component.css']
})
export class BookingPizzaComponent implements OnInit {
  pizzas: any;
  coupans: any;
  totalCost: number = 0;
  totalCount: number = 0;
   coupan="";
  constructor(private myservice: PizzaserviceService, private router: Router, private coupanservice: CoupanserviceService) {
  }

  ngOnInit(): any {
    this.coupanservice.viewCoupans().subscribe(
      response1 => this.handleSuccessfulResponse(response1),
    );
    this.myservice.getPizzas().subscribe(
      response => this.handleSuccessfulResponse(response),
    );
  }

  handleSuccessfulResponse1(response1) {
    this.coupans = response1;
  }
  handleSuccessfulResponse(response) {
    this.pizzas = response;
  }
  add(cost: number) {
    console.log(cost);
    this.totalCost += cost;
    console.log(this.totalCost);
    this.totalCount++;
  }
  remove(cost: number) {
    if(this.totalCost>0){
    console.log(cost);
  
    this.totalCost -= cost;
    this.totalCount--;
    if(this.totalCost<0){
      this.totalCost=0
    }
    console.log(this.coupan);
    }
  }
  flag:boolean=true;
  onSubmit() {
    if(this.flag){
    console.log("clA");
    if (this.coupan == "50") {
      this.totalCost /= 2;
    }
    else if (this.coupan == "20") {
      this.totalCost-=this.totalCost*0.2;
    }
    else {
      this.totalCost-=this.totalCost*0.1;
    }
    this.flag=false;
  }
  }

}
