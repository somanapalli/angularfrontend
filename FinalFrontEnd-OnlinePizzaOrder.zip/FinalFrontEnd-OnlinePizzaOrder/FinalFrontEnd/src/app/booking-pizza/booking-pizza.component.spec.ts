import { ComponentFixture, TestBed } from '@angular/core/testing';

import { BookingPizzaComponent } from './booking-pizza.component';

describe('BookingPizzaComponent', () => {
  let component: BookingPizzaComponent;
  let fixture: ComponentFixture<BookingPizzaComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ BookingPizzaComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(BookingPizzaComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
