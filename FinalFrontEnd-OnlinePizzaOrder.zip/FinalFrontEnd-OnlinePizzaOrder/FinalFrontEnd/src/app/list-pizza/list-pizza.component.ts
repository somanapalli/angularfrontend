import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { PizzaserviceService, Pizzas } from '../pizzaservice.service';
@Component({
  selector: 'app-list-pizza',
  templateUrl: './list-pizza.component.html',
  styleUrls: ['./list-pizza.component.css']
})
export class ListPizzaComponent implements OnInit {
  SortedColumn:string;
  message: string ="";
  pizzas!: Pizzas[];
  constructor(private myservice: PizzaserviceService, private router: Router) {
  }

  ngOnInit(): any {
    this.myservice.getPizzas().subscribe(
      response => this.handleSuccessfulResponse(response),
    );
  }

  handleSuccessfulResponse(response) {
    this.pizzas = response;
  }
  update(updatepizza: Pizzas) {
    this.myservice.update(updatepizza);
    this.router.navigate(['/updatepizza']); //updating the employee
  }
  delete(deletepizza): any {
    var selection=confirm("Are you sure to delete pizza permanently ?");
    if(selection==true){
    this.pizzas.splice(this.pizzas.indexOf(deletepizza), 1);
    this.myservice.delete(deletepizza).subscribe(data => {
      alert(data);

    });
    this.router.navigate(['/listpizza']);
  }
  }
  column:string="pizzaId";
  order:string="ascending";
  sort(column:string,order:string){
    this.column=column;
   if(this.order=="ascending")
   this.order="descending";
   else this.order="ascending";
  }
}
