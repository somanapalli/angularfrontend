import {​​​​​ Injectable }​​​​​ from '@angular/core';
import {​​​​​ HttpClient, HttpHeaders }​​​​​ from '@angular/common/http';
@Injectable({​​​​​
  providedIn: 'root'
}​​​​​)
export class PizzaserviceService {​​​​​
  updatepizza!: Pizzas;
  constructor(private httpService: HttpClient) {​​​​​ }​​​​​
  public getPizzas() {​​​​​
    console.log("ins service get pizzas");
    const headers =new HttpHeaders().set('Content_Type', 'text/plain ;charset=utf-8');
    return this.httpService.get<Pizzas>("http://localhost:1222/pizza/allPizza");
  }​​​​​
  public addPizz(addpizz: Pizzas) {​​​​​
    console.log("ins service add");
    console.log(addpizz);
    const headers =new HttpHeaders().set('Content_Type', 'text/plain ;charset=utf-8');
    return this.httpService.post("http://localhost:1222/pizza/addPizza", addpizz,  {​​​​​ headers, responseType: 'text'}​​​​​);
  }​​​​​
  
  public update(updatepizza: Pizzas) {​​​​​
    this.updatepizza = updatepizza;
  }​​​​​
  public updateMethod() {​​​​​
    return this.updatepizza;
  }​​​​​
  public onUpdate(updatepizz: Pizzas) {​​​​​
    console.log("ins service update");
    const headers =new HttpHeaders().set('Content_Type', 'text/plain ;charset=utf-8');
    return this.httpService.put("http://localhost:1222/pizza/updatePizza", updatepizz,  {​​​​​ headers, responseType: 'text'}​​​​​);
  }​​​​​
  delete(id: number) {​​​​​
    console.log("ins service delete");
    const headers =new HttpHeaders().set('Content_Type', 'text/plain ;charset=utf-8');
    return this.httpService.delete("http://localhost:1222/pizza/removePizza/" + id,  {​​​​​ headers, responseType: 'text'}​​​​​);
  }​​​​​
}​​​​​
export class Pizzas {​​​​​
  
  
  pizzaId: number=0;
  pizzaType: string="";
  pizzaName: string="";
  pizzaDescription: string=" ";
  pizzaCost: number=0;
  pizzaCostAfterCoupon: number=0;
}​​​​​