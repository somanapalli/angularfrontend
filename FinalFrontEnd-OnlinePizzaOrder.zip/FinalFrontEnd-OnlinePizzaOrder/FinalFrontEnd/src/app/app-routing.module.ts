import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { ListCustomerComponent } from './list-customer/list-customer.component';
import { UpdateCustomerComponent } from './update-customer/update-customer.component';
import { CreateCustomerComponent } from './create-customer/create-customer.component';
import { HomepageComponent } from './homepage/homepage.component';
import { ContactUSComponent } from './contact-us/contact-us.component';
import { LoginComponent } from './login/login.component';
import { ProfileComponent } from './profile/profile.component';
import { UpdateProfileComponent } from './update-profile/update-profile.component';
import { InterfaceComponent } from './interface/interface.component';
import { AddPizzaComponent } from './add-pizza/add-pizza.component';
import { UpdatePizzaComponent } from './update-pizza/update-pizza.component';
import { ListPizzaComponent } from './list-pizza/list-pizza.component';
import { ListCoupanComponent } from './list-coupan/list-coupan.component';
import { AddCoupanComponent } from './add-coupan/add-coupan.component';
import { UpdateCoupanComponent } from './update-coupan/update-coupan.component';
import { BookingPizzaComponent } from './booking-pizza/booking-pizza.component';



const routes: Routes = [{ path: 'listcus', component: ListCustomerComponent },
{ path: 'addcus', component: CreateCustomerComponent },
{ path: '', component: HomepageComponent },
{ path: 'home/:id', component: HomepageComponent },
{path:'profile/:id',component:ProfileComponent},
{ path: 'updatecus', component: UpdateCustomerComponent },
{ path: 'homepage', component: HomepageComponent },
{ path: 'contact', component: ContactUSComponent },
{ path: 'login', component: LoginComponent },
{path:'profile', component:ProfileComponent},
{path :'updateprofile',component:UpdateProfileComponent},
{path:'interface',component:InterfaceComponent},
{path:'listpizza/addpizza',component:AddPizzaComponent},
{path:'updatepizza',component:UpdatePizzaComponent},
{path:'listpizza',component:ListPizzaComponent},
{path:'list-coupans',component:ListCoupanComponent},
{path: 'list-coupans/add-coupan',component:AddCoupanComponent},
{path:'update-coupan',component:UpdateCoupanComponent},
{path:'bookpizza',component:BookingPizzaComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
