import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import {FormsModule} from '@angular/forms';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { CreateCustomerComponent } from './create-customer/create-customer.component';
import { ListCustomerComponent } from './list-customer/list-customer.component';
import { UpdateCustomerComponent } from './update-customer/update-customer.component';
import { HttpClient, HttpClientModule } from '@angular/common/http';
import { HomepageComponent } from './homepage/homepage.component';
import { ContactUSComponent } from './contact-us/contact-us.component';
import { LoginComponent } from './login/login.component';
import { ProfileComponent } from './profile/profile.component';
import { FilterComponent } from './filter/filter.component';
import { OrderByPipe } from './list-customer/order-by.pipe';
import { UpdateProfileComponent } from './update-profile/update-profile.component';
import { InterfaceComponent } from './interface/interface.component';
import { UpdatePizzaComponent } from './update-pizza/update-pizza.component';
import { ListPizzaComponent } from './list-pizza/list-pizza.component';
import { AddPizzaComponent } from './add-pizza/add-pizza.component';
import { UpdateCoupanComponent } from './update-coupan/update-coupan.component';
import { AddCoupanComponent } from './add-coupan/add-coupan.component';
import { ListCoupanComponent } from './list-coupan/list-coupan.component';
import { BookingPizzaComponent } from './booking-pizza/booking-pizza.component';

@NgModule({
  declarations: [
    AppComponent,
    CreateCustomerComponent,
    ListCustomerComponent,
    UpdateCustomerComponent,
    HomepageComponent,
    ContactUSComponent,
    LoginComponent,
    ProfileComponent,
    FilterComponent,
    OrderByPipe,
    UpdateProfileComponent,
    InterfaceComponent,
    ListPizzaComponent,
    AddPizzaComponent,
    UpdatePizzaComponent,
    UpdateCoupanComponent,
    AddCoupanComponent,
    ListCoupanComponent,
    BookingPizzaComponent
    
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    HttpClientModule,FormsModule,
  ],
  providers: [HttpClient],
  bootstrap: [AppComponent]
})
export class AppModule { }
