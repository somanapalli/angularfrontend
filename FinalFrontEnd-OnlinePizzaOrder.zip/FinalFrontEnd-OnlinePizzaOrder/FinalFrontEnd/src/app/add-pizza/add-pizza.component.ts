import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { PizzaserviceService, Pizzas } from '../pizzaservice.service';
@Component({
  selector: 'app-add-pizza',
  templateUrl: './add-pizza.component.html',
  styleUrls: ['./add-pizza.component.css']
})
export class AddPizzaComponent implements OnInit {

  constructor(private myservice: PizzaserviceService,private router: Router) { }

  ngOnInit(): void {
  }
  onSubmit(addpizz:Pizzas):any{
    addpizz.pizzaId=123;
    console.log(addpizz);
    var selection=confirm("Confirm pizza details once before adding! Are you sure to add?");
    if(selection==true){
     this.myservice.addPizz(addpizz).subscribe(data => {
      alert(data);
      this.router.navigate(['/listpizza']);
    });
  }
}
}
