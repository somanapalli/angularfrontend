import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Coupan, CoupanserviceService } from '../coupanservice.service';

@Component({
  selector: 'app-add-coupan',
  templateUrl: './add-coupan.component.html',
  styleUrls: ['./add-coupan.component.css']
})
export class AddCoupanComponent implements OnInit {

  constructor(private myservice: CoupanserviceService, private router: Router) { }

  ngOnInit(): void {
  }
  onSubmit(addcou: Coupan): any {
    var selection = confirm("Confirm your Details!");
    if (selection) {
      console.log("Data added Successfully!");
      console.log(addcou);
      this.myservice.addCoupan(addcou).subscribe(data => {
        alert("Coupan Added Successfully");
        this.router.navigate(['/list-coupans']);
      });
    }

  }

}