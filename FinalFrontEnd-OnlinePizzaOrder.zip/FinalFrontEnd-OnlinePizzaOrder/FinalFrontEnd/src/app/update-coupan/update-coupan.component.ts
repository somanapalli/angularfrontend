import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Coupan, CoupanserviceService } from '../coupanservice.service';

@Component({
  selector: 'app-update-coupan',
  templateUrl: './update-coupan.component.html',
  styleUrls: ['./update-coupan.component.css']
})
export class UpdateCoupanComponent implements OnInit {
  obj1: any;
  coupan: Coupan[] = [];
  
  constructor(private myservice:CoupanserviceService,private router:Router) {
    this.obj1 = this.myservice.updateMethod();
   }
   onUpdate(ucou:Coupan):any{
     return this.myservice.onUpdate(ucou).subscribe(data=>{
       alert("Updated successfully")
       this.router.navigate(['/list-coupans'])
     });
   }

  ngOnInit(): void {
  }

}