import { ComponentFixture, TestBed } from '@angular/core/testing';

import { UpdateCoupanComponent } from './update-coupan.component';

describe('UpdateCoupanComponent', () => {
  let component: UpdateCoupanComponent;
  let fixture: ComponentFixture<UpdateCoupanComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ UpdateCoupanComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(UpdateCoupanComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
