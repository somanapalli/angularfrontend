import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { PizzaserviceService, Pizzas } from '../pizzaservice.service';
@Component({
  selector: 'app-update-pizza',
  templateUrl: './update-pizza.component.html',
  styleUrls: ['./update-pizza.component.css']
})
export class UpdatePizzaComponent implements OnInit {

  
  obj1: any;
  pizzas!: Pizzas[];
  message!: string;
  constructor(private myservice: PizzaserviceService, private router: Router) {
    this.obj1 = this.myservice.updateMethod();
  }
  onUpdate(upizza: Pizzas): any {
    var selection=confirm("Ensure update details,Are you sure to update?");
    if(selection==true){
    return this.myservice.onUpdate(upizza).subscribe(data => {
      alert(data)
      this.router.navigate(['/listpizza'])
    });
  }
}
  ngOnInit(): void {
  }

}
