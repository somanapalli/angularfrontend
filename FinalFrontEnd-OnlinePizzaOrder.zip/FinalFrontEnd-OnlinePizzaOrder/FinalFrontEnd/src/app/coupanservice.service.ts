import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class CoupanserviceService {

  updateCoupan: Coupan = new Coupan;
  constructor(private httpService: HttpClient) { }


  public viewCoupans() {
    console.log("ins service get coupans");
    const headers =new HttpHeaders().set('Content_Type', 'text/plain ;charset=utf-8');
    return this.httpService.get<Coupan>("http://localhost:1222/coupans/all");
  }

  addCoupan(addcou: Coupan) {
    console.log("ins service add");
    console.log(addcou);
    const headers =new HttpHeaders().set('Content_Type', 'text/plain ;charset=utf-8');
    return this.httpService.post("http://localhost:1222/coupans/create", addcou,  { headers, responseType: 'text'});
  }
  
  public update(updateCoupan: Coupan) {
    this.updateCoupan = updateCoupan;
  }
  public updateMethod() {
    return this.updateCoupan;
  }
  public onUpdate(updatecou: Coupan) {
    console.log("ins service update");
    const headers =new HttpHeaders().set('Content_Type', 'text/plain ;charset=utf-8');
    return this.httpService.put("http://localhost:1222/coupans/update", updatecou,  { headers, responseType: 'text'});
  }
  public deleteCoupan(coupanId: number) {
    console.log("ins service delete");
    const headers =new HttpHeaders().set('Content_Type', 'text/plain ;charset=utf-8');
    return this.httpService.delete("http://localhost:1222/coupans/delete?id=" + coupanId,  { headers, responseType: 'text'});
  }

}
export class Coupan {
  coupanId: number=0;
  coupanName: string="";
  coupanType: string="";
  coupanDescription: string="";
  coupanPizzaId: number=0;

 
  
}
